#include <stdio.h>
#include <stdlib.h>
#include "fib_ops.h"

int main() {
    int n;

    printf("Enter the number of terms to compute for the Fibonnaci sequence: ");
    
    if (scanf("%d", &n) != 1 || n < 0) {
        printf("Invalid input, please make sure your input is a non-negative integer.\n");
        return 1;
    }

    print_fibonacci_sequence(n);

    return 0;
}