#include <stdio.h>
#include "fib_ops.h"

void print_fibonacci_sequence(int n) {
    int first = 0;
    int second = 1;
    int next;
    int i;

    printf("\nFibonnaci Sequence (First %d terms):\n", n);

    if (n == 0) {
        printf("\n");
    } 
    else if (n == 1) {
        printf("%d,\n ", first);
    }
    else {
        printf("%d, %d, ", first, second);

        for (i = 3; i <= n; i++) {
            next = first + second;
            
            printf("%d, ", next);
            first = second;
            second = next;
        }
        printf("\n");
    }
}