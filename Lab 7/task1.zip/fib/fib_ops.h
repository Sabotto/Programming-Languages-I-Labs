#ifndef FIB_OPS_H
#define FIB_OPS_H

void print_fibonacci_sequence(int n); 

#endif